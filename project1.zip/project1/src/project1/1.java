class phone{
	void voicecall() {
		System.out.println("Make Voicecalls");
	}
	void sms() {
		System.out.println("we can send sms");
	}
}
interface camera{
	void click();
	void record();
}
interface player{
	void play();
	void pause();
	void stop();
}
class smartphone extends phone implements camera,player
{
	public void click() {
		System.out.println("you can make multiple click");
}
	public void record() {
		System.out.println("you can record videos");
}
	public void play() {
		System.out.println("you can play songs");
}
	public void pause() {
		System.out.println("you can pause songs");
}
	public void stop() {
		System.out.println("you can stop the songs");
}
}
class oops{
	public static void main(string[]args) {
		phone o=new Smartphone();
		o.voicecall();
		o.sms();
		o.click();
		o.record();
		o.play();
		o.pause();
		o.stop();
	}
}
