package project1;
import java.util.*;
public class first {
	public static void main(String[] args) {
int a[]= {1,4,7,2,9};
String s=Arrays.toString(a);
System.out.println("tostring : "+s);
int marks[]= {50,30,20,60,40,80};
for(int i=0;i<=marks.length;i++)
{
	Arrays.sort(marks);
}
System.out.println("sorting order: "+Arrays.toString(marks));
if (marks.length > 1) {
    int secondLargest = marks[marks.length - 2];  
    System.out.println("Second largest number: " + secondLargest);
} else {
    System.out.println("Array has less than 2 elements, no second largest number.");
}
int d[]=Arrays.copyOf(a, 10);
System.out.println("resize an array : "+Arrays.toString(d));
if(d.equals(marks))
{
	System.out.println("equal");
}
else
{
	System.out.println("not equal");
}
Arrays.fill(d,5,10, 7);
System.out.println("filling array : "+ Arrays.toString(d));
int e=Arrays.binarySearch(marks, 40);
System.out.println("binarySearch : "+e);
int j=0;
int f[]=new int[marks.length];
for(int i=marks.length-1;i>=0;i--)
{
    f[j]=marks[i];
	j++;
}
System.out.println("reverse array is : "+Arrays.toString(f));

        int maxValue = 0;
        for (int num : a)
        {
            if (num > maxValue)
            {
                maxValue = num;
            }
        }
        int[] count = new int[maxValue + 1]; 
        for (int num : a) {
            count[num]++;
        }
        for (int i = 0; i < count.length; i++)
        {
           if (count[i] > 0) 
           {
        	   System.out.println(i + " appears " + count[i] + " times.");
            }
        }

}
}