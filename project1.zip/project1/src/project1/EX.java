class phone{
	void voicecall() {
		System.out.println("Make Voicecalls");
	}
	void sms() {
		System.out.println("we can send sms");
	}
}
interface camera{
	void click();
	void record();
}
interface player{
	void play();
	void pause();
}

