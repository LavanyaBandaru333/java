package project1;

import java.util.Arrays;

public class crt2 {
	public static void main(String[] args) {
	String s="Annamacharya Institute of technology";
	String s2="lavanya";
	int count=0;
	int s1=	s.length();
	System.out.println("length : "+s1);
	char c1=s.charAt(0);
	System.out.println(c1);
	char c2=s.charAt(s.length()-1);
    System.out.println(c2);
    System.out.println(s.contains("Institute"));
    if(s2.equalsIgnoreCase("lavanya"))
    {
    	System.out.println("sucessful");
    }
    else
    {
    	System.out.println("invalid");
    }
    String s4[]=s.trim().split(" ");
    if(s4.length==0)
    {
    	System.out.println("no data found");
    }
    else if(s4.length==1)
    {
    	System.out.println("first : "+s4[0]);
    }
    else
    {
    	System.out.println("first : "+s4[0]);
    	System.out.println("last : "+s4[s4.length-1]);
    }
   System.out.println( s.replace(" ","-"));
   System.out.println(s2);
   System.out.println(s2.trim());
   System.out.println(s2.toLowerCase());
   String s5=new String();
   for(int i=s2.length()-1;i>=0;i--)
   {
	   s5+=s2.charAt(i);
   }
   if(s2.equals(s5))
   {
	   System.out.println("palindrom");
   }
   else
   {
	   System.out.println("not palindrome");
   }
  String s6= Arrays.toString(s2.toCharArray());
    System.out.println( s6);
	for(int i=1;i<=s2.length();i++)
	{
	for(int j=2;j<=s2.length();j++)
	{
	 if(s6.charAt(i)==s6.charAt(j))
	  {
		count++;
	  }
	
	  }
	System.out.println("count of "+s6.charAt(i)+"   "+count);
	
	 }
	}

}
