import java.util.Scanner;
class method{
 void method1(){
System.out.println("this is number convertion");
int num=245;
double num1=num;
System.out.println(num);
System.out.println(num1);
}
void method2(){
		System.out.println("another class");
		Scanner num=new Scanner(System.in);
		int n=num.nextInt();
		for(int i=0;i<=n;i++){
		System.out.println("for loop");
		}
}
public static void main(String[] args){
	method1();
	method2();
}
}

