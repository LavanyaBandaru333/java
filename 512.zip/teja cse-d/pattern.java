class Pattern{
public static void main(String [] args)
{
int i=25;
System.out.println(i);
}
}
